import React from 'react';

const MyOrders = () => {
    return (
        <div>
            <h2 className='text-3xl font-bold text-primary m-2'>My Orders</h2>
        </div>
    );
};

export default MyOrders;