import React from 'react';

const AllOrder = () => {
    return (
        <div>
            <h1 className='text-xl py-2 text-primary text-center font-bold'>Your All Orders Here </h1>
        </div>
    );
};

export default AllOrder;