import React from 'react';
import Products from '../../Home/Product/Products';
import AllProducts from '../AllProducts/AllProducts';

const ManageProducts = () => {
    return (
        <div>
            <AllProducts></AllProducts>
        </div>
    );
};

export default ManageProducts;